#
# This file is part of GreatFET
#

class GreatFETPeripheral(object):
    """
    Generic base class for GreatFET peripherals.
    """
    pass
